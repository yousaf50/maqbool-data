<?php
/**
 * The Template for displaying tours in a tour_type taxonomy . Simply includes the archive template.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

trav_get_template( 'archive-tour.php' );