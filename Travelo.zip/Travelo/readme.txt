#### change log - 1.9.5 #####
/css/rtl/rtl.min.css
/css/rtl/rtl.css
/inc/admin/accommodation/vacancies-admin-panel.php
/inc/frontend/accommodation/ajax.php
/inc/functions/js_composer/js_composer.php
/inc/functions/functions.php
/inc/functions/woocommerce/woocommerce.php
/inc/functions/metaboxes.php
/js/theme-scripts.js
/templates/headers/header.php
/templates/headers/header1.php
/templates/headers/header2.php
/templates/headers/header3.php
/templates/headers/header4.php
/templates/headers/header5.php
/templates/headers/header6.php
/templates/headers/header7.php
/woocommerce/checkout/thankyou.php
/woocommerce/global/quantity-input.php
/woocommerce/order/order-details-customer.php
/woocommerce/order/order-details.php
/woocommerce/single-product-reviews.php
/header.php
/searchform.php
/single-tour.php
/taxonomy-location.php
/style.css

#### change log - 1.9.4 #####
/inc/admin/accommodation/bookings-admin-panel.php
/inc/admin/accommodation/reviews-admin-panel.php
/inc/admin/accommodation/vacancies-admin-panel.php
/inc/admin/tour/bookings-admin-panel.php
/inc/admin/tour/schedule-admin-panel.php
/inc/admin/currencies-admin-panel.php
/inc/frontend/tour/functions.php
/inc/functions/js_composer/vc_templates/vc_tabs.php
/inc/functions/js_composer/init.php
/inc/functions/js_composer/js_composer.php
/inc/functions/currency.php
/inc/functions/functions.php
/inc/frontend/accommodation/templates.php
/js/page-loading.js
/js/theme-scripts.js
/woocommerce/cart/cart-empty.php
/woocommerce/cart/cart.php
/woocommerce/checkout/form-billing.php
/woocommerce/checkout/form-shipping.php
/woocommerce/single-product/product-image.php
/woocommerce/single-product/rating.php
/functions.php
/single-accommodation.php
/style.css

#### change log - 1.9.3 #####
/inc/functions/functions.php
/js/theme-scripts.js
/templates/headers/header.php
/templates/headers/header1.php
/templates/headers/header2.php
/templates/headers/header3.php
/templates/headers/header4.php
/templates/headers/header5.php
/templates/headers/header6.php
/templates/headers/header7.php
/templates/template-login.php
/woocommerce/cart/cart.php
/functions.php
/single-accommodation.php
/single-tour.php
/style.css

#### change log - 1.9.2 #####
/inc/functions/woocommerce/woocommerce.php
/woocommerce/checkout/thankyou.php
/woocommerce/order/order-details-customer.php
/woocommerce/order/order-details.php

#### change log - 1.9.1 #####
/inc/admin/accommodation/bookings-admin-panel.php
/inc/admin/tour/bookings-admin-panel.php
/inc/frontend/accommodation/ajax.php
/inc/frontend/accommodation/functions.php
/inc/frontend/tour/ajax.php
/inc/frontend/tour/functions.php
/inc/functions/woocommerce/woocommerce.php
/inc/functions/db.php
/inc/functions/functions.php
/inc/lib/meta-box/inc/fields/rev-slider.php
/inc/lib/redux-framework/templates/acc_admin_email_description.htm
/inc/lib/redux-framework/templates/acc_bowner_email_description.htm
/inc/lib/redux-framework/templates/acc_cancel_admin_email_description.htm
/inc/lib/redux-framework/templates/acc_cancel_bowner_email_description.htm
/inc/lib/redux-framework/templates/acc_cancel_email_description.htm
/inc/lib/redux-framework/templates/acc_confirm_email_description.htm
/inc/lib/redux-framework/templates/acc_update_admin_email_description.htm
/inc/lib/redux-framework/templates/acc_update_bowner_email_description.htm
/inc/lib/redux-framework/templates/acc_update_email_description.htm
/inc/lib/redux-framework/config.php
/inc/lib/multiple_sidebars.php
/templates/accommodation/accommodation-booking.php
/templates/accommodation/booking-success.php
/templates/tour/booking-success.php
/templates/tour/tour-booking.php
/woocommerce/cart/cart.php
/woocommerce/checkout/form-shipping.php
/woocommerce/single-product/product-image.php
/woocommerce/content-single-product.php
/archive-accommodation.php
/archive-tour.php
/functions.php
/single-room_type.php
/taxonomy-location.php
/style.css

#### change log - 1.9.0 #####
\css\sass\base.scss
\css\sass\main.scss
\css\sass\mixin.scss
\css\sass\responsive.scss
\css\sass\variables.scss
\css\style-dark-blue.css
\css\style-dark-orange.css
\css\style-light-blue.css
\css\style-light-orange.css
\css\style-light-yellow.css
\css\style-orange.css
\css\style-purple.css
\css\style-red.css
\css\style-sea-blue.css
\css\style-sky-blue.css
\css\style.css
\inc\admin\accommodation\js\script.js
\inc\admin\tour\schedule-admin-panel.php
\inc\admin\accommodation\bookings-admin-panel.php
\inc\admin\accommodation\reviews-admin-panel.php
\inc\admin\accommodation\vacancies-admin-panel.php
\inc\admin\tour\bookings-admin-panel.php
\inc\admin\currencies-admin-panel.php
\inc\frontend\accommodation\functions.php
\inc\frontend\tour\functions.php
\inc\frontend\tour\main.php
\inc\functions\js_composer\js_composer.php
\inc\functions\shortcode\init.php
\inc\functions\shortcode\shortcodes.php
\inc\functions\woocommerce\woocommerce.php
\inc\functions\functions.php
\inc\functions\main.php
\inc\lib\meta-box\inc\loader.php
\inc\lib\meta-box\js\clone.js
\js\theme-scripts.js
\header.php
\templates\headers\header.php
\templates\headers\header1.php
\templates\headers\header2.php
\templates\headers\header3.php
\templates\headers\header4.php
\templates\headers\header5.php
\templates\headers\header6.php
\templates\headers\header7.php
\templates\inners\inner-1.php

#### change log - 1.8.0 #####
\inc\frontend\tour\templates.php
\inc\functions\functions.php
\inc\functions\main.php
\inc\functions\taxonomy-meta.php
\inc\lib\redux-framework\ReduxCore\inc\welcome\welcome.php
\js\theme-scripts.js
\woocommerce\order\order-details.php
\functions.php
\style.css

#### change log - 1.7.3 #####
/inc/functions/functions.php
/inc/functions/main.php
/inc/functions/metaboxes.php
/inc/lib/redux-framework/config.php
/functions.php
/style.css

#### change log - 1.7.2 #####
/style.css
/functions.php
/inc/lib/meta-box

#### change log - 1.7.1 #####
/style.css
/functions.php
/inc/functions/functions.php
/single-room_type.php

#### change log - 1.7 #####
/inc/functions/woocommerce/woocommerce.php
/woocommerce/cart/cart-empty.php
/woocommerce/cart/cart-totals.php
/woocommerce/cart/cart.php
/woocommerce/checkout/form-billing.php
/woocommerce/checkout/form-checkout.php
/woocommerce/checkout/form-shipping.php
/woocommerce/checkout/review-order.php
/woocommerce/checkout/thankyou.php
/woocommerce/order/order-details.php
/inc/functions/js_composer/js_composer.php
/inc/lib/payment/main.php
/functions.php
/style.css

#### change log - 1.6.3 #####
/style.css
/functions.php
/inc/frontend/tour/functions.php
/inc/frontend/accommodation/functions.php

#### change log - 1.6.2 #####
/style.css
/functions.php
/templates/tour/tour-list.php
/templates/tour/booking-success.php
/inc/functions/functions.php
/inc/functions/shortcode/shortcodes.php
/inc/functions/js_composer/js_composer.php
/inc/functions/js_composer/vc_templates/vc_tabs.php
/inc/functions/js_composer/vc_templates/vc_tab.php
/inc/functions/js_composer/vc_templates/vc_row.php
/inc/functions/js_composer/vc_templates/vc_accordion_tab.php
/inc/functions/js_composer/vc_templates/vc_accordion.php
/css/responsive.css
/css/custom.css

#### change log - 1.6.1 #####
/style.css
/css/responsive.css
/inc/frontend/accommodation/functions.php
/inc/frontend/tour/functions.php
/inc/functions/functions.php
/inc/functions/currency.php
/functions.php

#### change log - 1.6.0 #####
/css/style.css
/inc/admin/accommodation/bookings-admin-panel.php
/inc/admin/tour/bookings-admin-panel.php
/inc/frontend/accommodation/functions.php
/inc/frontend/tour/functions.php
/inc/functions/js_composer/vc_templates/vc_tabs.php
/inc/functions/js_composer/js_composer.php
/inc/functions/shortcode/shortcodes.php
/inc/functions/functions.php
/inc/lib/redux-framework/config.php
/js/theme-scripts.js
/js/tour.js
/templates/accommodation/accommodation-list.php
/templates/user/accommodation.php
/functions.php
/single-accommodation.php
/style.css
/inc/functions/currency.php

#### change log - 1.5.9 #####
/inc/admin/accommodation/bookings-admin-panel.php
/inc/admin/accommodation/main.php
/inc/admin/tour/bookings-admin-panel.php
/inc/admin/tour/schedule-admin-panel.php
/inc/frontend/tour/functions.php
/inc/functions/js_composer/js_composer.php
/inc/functions/shortcode/shortcodes.php
/js/theme-scripts.js
/templates/accommodation/accommodation-booking-confirmation.php
/templates/tour/tour-booking-confirmation.php
/functions.php
/single-accommodation.php
/style.css

#### change log - 1.5.8 #####
/inc/admin/accommodation/bookings-admin-panel.php
/inc/admin/accommodation/vacancies-admin-panel.php
/inc/functions/wpml.php
/single-accommodation.php
/inc/functions/functions.php
/header.php
/templates/headers/header.php
/templates/headers/header2.php
/templates/headers/header4.php
/templates/headers/header6.php
/templates/headers/header7.php
/style.css

/inc/admin/accommodation/reviews-admin-panel.php
/inc/frontend/accommodation/ajax.php
/single-accommodation.php

#### change log - 1.5.7 #####
/inc/functions/currency.php
/inc/functions/widget.php
/inc/functions/shortcode/shortcodes.php
/inc/functions/functions.php
/style.css
#### change log - 1.5.5 #####
/css/style.css
/inc/admin/accommodation/main.php
/inc/admin/tour/main.php
/inc/frontend/accommodation/functions.php
/inc/frontend/tour/functions.php
/inc/functions/functions.php
/inc/functions/widget.php
/js/theme-scripts.js
/templates/booking/booking-form.php
/templates/user/profile.php
/archive.php
/style.css
#### change log - 1.5.4 #####
/css/custom.css
/inc/admin/tour/schedule-admin-panel.php
/inc/frontend/tour/templates.php
/inc/functions/shortcode/shortcodes.php
/inc/functions/db.php
/inc/functions/functions.php
/inc/functions/metaboxes.php
/js/theme-scripts.js
/templates/loop-blog.php
/templates/template-login.php
comments.php
functions.php
single-post.php
#### change log - 1.5.3 #####
/inc/frontend/tour/templates.php
/inc/functions/custom-menu/custom-menu.php
/inc/functions/shortcode/shortcodes.php
/inc/lib/payment/main.php
/inc/lib/multiple_sidebars.php
#### change log - 1.5.1 #####
/inc/functions/user.php
updated visual composer to latest version
#### change log - 1.5 #####
/css/sass/base.scss
/css/sass/main.scss
/css/bootstrap.scss
/css/bootstrap.min.scss
/css/custom.scss
/css/style-dark-blue.css
/css/style-dark-orange.css
/css/style-light-blue.css
/css/style-light-orange.css
/css/style-light-yellow.css
/css/style-orange.css
/css/style-purple.css
/css/style-red.css
/css/style-sea-blue.css
/css/style-sky-blue.css
/css/style.css
/inc/admin/main.php
/inc/frontend/tour/functions.php
/inc/frontend/tour/templates.php
/inc/functions/js_composer
/inc/functions/shortcode/shortcodes.php
/inc/functions/functions.php
/inc/lib/meta-box/inc/field/taxonomy.php
/inc/lib/multiple_sidebars.php
/inc/plugins/js_composer.php
/js/theme-scripts.js
/templates/accommodation/accommodation-booking.php
/templates/tour/tour-booking.php
/templates/user/profile.php
/templates/template-business-owner-signup.php
/templates/template-login.php
functions.php
style.css

#### change log - 1.4.2 #####

archive-accommodation.php
archive-tour.php
functions.php
header.php
single-travel_guide.php
style.css
/css/sass/main.scss
/css/style-dark-blue.css
/css/style-dark-orange.css
/css/style-light-blue.css
/css/style-light-orange.css
/css/style-light-yellow.css
/css/style-orange.css
/css/style-purple.css
/css/style-red.css
/css/style-sea-blue.css
/css/style-sky-blue.css
/css/style.css
/inc/admin/accommodation/bookings-admin-panel.php
/inc/admin/accommodation/main.php
/inc/admin/tour/bookings-admin-panel.php
/inc/admin/tour/main.php
/inc/frontend/accommodation/funcitons.php
/inc/frontend/tour/funcitons.php
/inc/functions/shortcode/js/tinymce.js
/inc/functions/shortcode/js/tinymce.min.js
/inc/functions/shortcode/shortcodes.php
/inc/functions/currency.php
/inc/functions/db.php
/inc/functions/functions.php
/inc/functions/main.php
/inc/functions/metaboxes.php
/inc/functions/side-bar.php
/inc/functions/user.php
/languages/default.mo
/languages/default.po
/templates/headers/header.php
/templates/headers/header2.php
/templates/headers/header4.php
/templates/headers/header6.php
/templates/headers/header7.php
/templates/user/accommodation.php
/templates/user/account.php
/templates/user/booking-history.php
/templates/user/dashboard.php
/templates/user/main.php
/templates/user/profile.php
/templates/user/wishlist.php
/templates/template-bg-slider.php