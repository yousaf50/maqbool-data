<?php
/**
 * The Template for displaying accommodations in a amenity tag . Simply includes the archive template.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

trav_get_template( 'archive-accommodation.php' );